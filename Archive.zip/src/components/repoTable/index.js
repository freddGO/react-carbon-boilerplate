import RepoPage from "./RepoTable";

export default RepoPage;
